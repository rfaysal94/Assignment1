import React, { Component, useState, useEffect } from "react";
import Box from "@material-ui/core/Box";
import { Typography } from "@material-ui/core";
import ChartistGraph from "react-chartist";
import { get_chart1, get_chart2 } from "../../services/smallGraph.service";

export default function Repairs() {
  const [chart1, setChart1] = useState({ series: [], labels: [] });
  const [chart2, setChart2] = useState({ series: [], labels: [] });

  const line_graph_options = {
    high: 3,
    low: -3,
    showArea: false,
    color: "green",
    showLine: true,
    showPoint: false,
    fullWidth: true,
    height: "60",
    axisX: {
      showLabel: false,
      showGrid: false,
    },
    axisY: {
      showLabel: false,
      showGrid: false,
    },
    className: "line-green",
  };
  useEffect(() => {
    get_chart1(({ labels, series }) => setChart1({ labels, series }));
    get_chart2(({ labels, series }) => setChart2({ labels, series }));
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      get_chart1(({ labels, series }) => setChart1({ labels, series }));
      get_chart2(({ labels, series }) => setChart2({ labels, series }));
    }, 1000);
    return () => clearInterval(interval);
  }, []);
  const type = "Line";
  return (
    <>
      <Box
        display="flex"
        className="res_repair"
        flexDirection="row"
        alignItems="center"
        px={2}
      >
        {/* Repir 1 */}
        <Box
          borderRadius={16}
          bgcolor="#0D0B21"
          px={2}
          pt={1}
          mr={3}
          display="flex"
          flexDirection="row"
          alignItems="center"
        >
          <Typography
            className="repair_text_parent"
            variant="body1"
            display="block"
            gutterBottom
          >
            <span className="repair_text">Repairs</span>
          </Typography>
          {/* Line Graph 1 */}
          <ChartistGraph
            data={chart1}
            options={line_graph_options}
            type={type}
          />
          <Box display="flex" flexDirection="column" alignItems="center">
            <span className="repairs_value">
              15 <span className="repairs_des">cars</span>
            </span>
            <span className="repairs_des">+12.5%</span>
          </Box>
        </Box>
        {/* Reair 2 */}
        <Box
          borderRadius={16}
          bgcolor="#0D0B21"
          px={2}
          pt={1}
          display="flex"
          flexDirection="row"
          alignItems="center"
        >
          <Typography
            className="repair_text_parent"
            variant="body1"
            display="block"
            gutterBottom
          >
            <span className="repair_text">Repairs</span>
          </Typography>
          {/* Line Graph 2 */}
          <ChartistGraph
            data={chart2}
            options={line_graph_options}
            type={type}
          />
          <Box display="flex" flexDirection="column" alignItems="center">
            <span className="repairs_value">
              15 <span className="repairs_des">cars</span>
            </span>
            <span className="repairs_des">+12.5%</span>
          </Box>
        </Box>
      </Box>
    </>
  );
}
