import React, { useEffect, useState } from "react";
import Box from "@material-ui/core/Box";
import { Typography } from "@material-ui/core";
import ChartistGraph from "react-chartist";
import {
  get_chart1,
  get_chart2,
  get_chart3,
} from "../../services/rightgraph.service";

export default function LineGraph() {
  const [chart1, setChart1] = useState({ series: [], labels: [] });
  const [chart2, setChart2] = useState({ series: [], labels: [] });
  const [chart3, setChart3] = useState({ series: [], labels: [] });

  useEffect(() => {
    get_chart1(({ labels, series }) => setChart1({ labels, series }));
    get_chart2(({ labels, series }) => setChart2({ labels, series }));
    get_chart3(({ labels, series }) => setChart3({ labels, series }));
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      get_chart1(({ labels, series }) => setChart1({ labels, series }));
      get_chart2(({ labels, series }) => setChart2({ labels, series }));
      get_chart3(({ labels, series }) => setChart3({ labels, series }));
    }, 1000);
  }, []);

  const line_graph_options = {
    showArea: false,
    color: "green",
    showLine: true,
    showPoint: false,
    fullWidth: true,
    height: "100",
    axisX: {
      showLabel: true,
      showGrid: false,
    },
    axisY: {
      showLabel: false,
      showGrid: false,
    },
    className: "line-green",
  };

  // var donut_option = {
  //   donut: true,
  //   donutWidth: 20,
  //   donutSolid: false,
  //   startAngle: 270,
  //   showLabel: false,
  // };

  var type = "Line";
  // var typePie = "Pie";

  return (
    <>
      <Box
        className="res_line"
        display="flex"
        flexDirection="column"
        alignItems="flex-start"
        px={2}
        bgcolor="black"
        borderRadius={16}
        color="white"
      >
        <Box display="flex" flexDirection="row" px={2}>
          {/* Spinner */}
          <div className="flexbox">
            <div className="triple-spinner"></div>
          </div>
          {/* Prices */}
          <Box
            display="flex"
            flexDirection="column"
            alignItems="center"
            justifyContent="center"
            px={2}
          >
            <Typography
              className="price_1"
              variant="button"
              display="block"
              gutterBottom
            >
              $ 2977.24 <small>INC</small>
            </Typography>
            <Typography
              className="price_2"
              variant="button"
              display="block"
              gutterBottom
            >
              75.55% <small>EXP</small>
            </Typography>
            <Typography
              className="price_3"
              variant="button"
              display="block"
              gutterBottom
            >
              34 <small>SALES</small>{" "}
            </Typography>
          </Box>
        </Box>
        {/* Line Graphs */}
        <Box
          display="flex"
          flexDirection="column"
          justifyContent="flex-start"
          px={2}
          className="line_graph_res"
        >
          {/* Chart 1 */}
          <ChartistGraph
            className="line_graph_chart"
            data={chart1}
            options={line_graph_options}
            type={type}
          />

          {/* Chart 2 */}
          <ChartistGraph
            className="line_graph_chart"
            data={chart2}
            options={line_graph_options}
            type={type}
          />

          {/* Chart 3 */}
          <ChartistGraph
            className="line_graph_chart"
            data={chart3}
            options={line_graph_options}
            type={type}
          />
        </Box>
      </Box>
    </>
  );
}
