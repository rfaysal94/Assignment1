import React, { Component } from "react";
import Box from "@material-ui/core/Box";
import Grid from "@material-ui/core/Grid";
import { Typography } from "@material-ui/core";
import Logo from "../images/vectorpaint.png";
import Header from "../images/Header.png";
import CloudQueueIcon from "@material-ui/icons/CloudQueue";
import ViewListIcon from "@material-ui/icons/ViewList";
import EqualizerIcon from "@material-ui/icons/Equalizer";
import SettingsIcon from "@material-ui/icons/Settings";
import WebIcon from "@material-ui/icons/Web";
import ListAltIcon from "@material-ui/icons/ListAlt";
import DateRangeIcon from "@material-ui/icons/DateRange";
import ExitToAppIcon from "@material-ui/icons/ExitToApp";
import { fade, makeStyles } from "@material-ui/core/styles";
import SearchIcon from "@material-ui/icons/Search";
import InputBase from "@material-ui/core/InputBase";
import NotificationsIcon from "@material-ui/icons/Notifications";
import Repairs from "./Repairs/repairs";
import Reporting from "./Reporting/reporting";
import LineGraph from "./LineGraph/lineGraph";

import "./assets/css/line.css";

const useStyles = makeStyles((theme) => ({
  search: {
    position: "relative",
    borderRadius: "17px",
    backgroundColor: fade(theme.palette.common.white, 1),
    color: "black",
    marginRight: theme.spacing(2),
    marginLeft: 0,
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      marginLeft: theme.spacing(3),
      width: "auto",
    },
  },
  searchIcon: {
    padding: theme.spacing(0, 2),
    height: "100%",
    position: "absolute",
    pointerEvents: "none",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  inputRoot: {
    color: "inherit",
  },
  inputInput: {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("md")]: {
      width: "23ch",
    },
  },
}));
export default function PrimarySearchAppBar() {
  const classes = useStyles();

  return (
    <>
      <Grid item xs={12}>
        <img className="main" src={Header} alt="" />
        {/* Main */}
        <Box py={4} className="dashboard">
          <Box
            bgcolor="#E3E9F2"
            color="background.paper"
            p={2}
            mx={8}
            borderRadius={16}
            display="flex"
            alignItems="flex-start"
            className="res_head"
          >
            {/* Sidebar */}
            <Box
              className="res_nav"
              p={1}
              bgcolor="#6418C3"
              display="flex"
              borderRadius={16}
              justifyContent="center"
              alignItems="center"
              flexDirection="column"
            >
              <img src={Logo} alt="" className="cursor" />
              <Box
                className="weather_box"
                bgcolor="#391272"
                display="flex"
                flexDirection="column"
                alignItems="center"
                p={2}
                my={5}
                borderRadius={16}
              >
                <CloudQueueIcon />
                <Typography variant="button" display="block" gutterBottom>
                  26°
                </Typography>
                <Typography
                  variant="body1"
                  display="block"
                  gutterBottom
                  className="weather"
                >
                  Cloudy <br /> Skies
                </Typography>
              </Box>
              {/* Icons */}
              <Box
                display="flex"
                flexDirection="column"
                alignItems="center"
                p={2}
                mb={5}
                className="icons"
              >
                <ListAltIcon className="cursor" style={{ color: "white" }} />
                <ViewListIcon className="cursor" />
                <EqualizerIcon className="cursor" />
                <SettingsIcon className="cursor" />
                <DateRangeIcon className="cursor" />
                <WebIcon className="cursor" />
              </Box>
              <Box
                display="flex"
                flexDirection="column"
                alignItems="center"
                p={2}
                mt={5}
                className="exit_con"
              >
                <ExitToAppIcon className="cursor exit_icon" />
              </Box>
            </Box>
            <Box display="flex" className="header" flexDirection="column">
              <Box
                py={1}
                display="flex"
                flexDirection="row"
                alignItems="center"
                justifyContent="space-between"
              >
                {/* Searchbar */}
                <Box
                  display="flex"
                  flexDirection="row"
                  alignItems="center"
                  px={2}
                  className="res_search_bar"
                >
                  <div className={`search ${classes.search}`}>
                    <div className={classes.searchIcon}>
                      <SearchIcon />
                    </div>
                    <InputBase
                      placeholder="Search…"
                      classes={{
                        root: classes.inputRoot,
                        input: classes.inputInput,
                      }}
                      inputProps={{ "aria-label": "search" }}
                    />
                  </div>
                  <Typography variant="body1" display="block" gutterBottom>
                    <span className="cons cursor">Feedback</span>
                  </Typography>
                  <Typography variant="body1" display="block" gutterBottom>
                    <span className="cons cursor">Help</span>
                  </Typography>
                </Box>
                {/* Notification log */}
                <Box
                  display="flex"
                  flexDirection="row"
                  alignItems="center"
                  px={2}
                  color="black"
                  className="notification"
                >
                  <NotificationsIcon className="cursor" />
                  <img
                    src="https://akm-img-a-in.tosshub.com/indiatoday/images/story/202102/google_pay__7__1200x768.jpeg?WJeXdcrm_vaY0K7AWpMp5bXZ65NH_4dg&size=770:433"
                    alt=""
                    className="cursor profile"
                    height="30px"
                    width="30px"
                  />
                </Box>
              </Box>
              <Box
                className="res_main"
                py={3}
                pl={3}
                display="flex"
                flexDirection="row"
                justifyContent="space-between"
              >
                {/* Imports */}
                <Box disply="flex" flexDirection="column">
                  <Repairs />
                  <Reporting />
                </Box>
                <LineGraph />
              </Box>
            </Box>
          </Box>
        </Box>
      </Grid>
    </>
  );
}
