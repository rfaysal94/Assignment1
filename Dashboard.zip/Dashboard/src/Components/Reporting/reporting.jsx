import React, { Component, useState, useEffect } from "react";
import Box from "@material-ui/core/Box";
import ChartistGraph from "react-chartist";
import { Typography } from "@material-ui/core";
import ArrowDropUpIcon from "@material-ui/icons/ArrowDropUp";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";

import {
  get_chart1,
  get_chart2,
  get_chart3,
  get_chart4,
  get_chart5,
  get_chart6,
} from "../../services/bottomgraph.service";

export default function Reporting() {
  const [chart1, setChart1] = useState({ series: [], labels: [] });
  const [chart2, setChart2] = useState({ series: [], labels: [] });
  const [chart3, setChart3] = useState({ series: [], labels: [] });
  const [chart4, setChart4] = useState({ series: [], labels: [] });
  const [chart5, setChart5] = useState({ series: [], labels: [] });
  const [chart6, setChart6] = useState({ series: [], labels: [] });

  const line_graph_options = {
    high: 3,
    low: -3,
    showArea: false,
    color: "green",
    showLine: true,
    showPoint: false,
    fullWidth: true,
    height: "60",
    axisX: {
      showLabel: false,
      showGrid: false,
    },
    axisY: {
      showLabel: false,
      showGrid: false,
    },
    className: "line-green",
  };

  useEffect(() => {
    get_chart1(({ labels, series }) => setChart1({ labels, series }));
    get_chart2(({ labels, series }) => setChart2({ labels, series }));
    get_chart3(({ labels, series }) => setChart3({ labels, series }));
    get_chart4(({ labels, series }) => setChart4({ labels, series }));
    get_chart5(({ labels, series }) => setChart5({ labels, series }));
    get_chart6(({ labels, series }) => setChart6({ labels, series }));
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      get_chart1(({ labels, series }) => setChart1({ labels, series }));
      get_chart2(({ labels, series }) => setChart2({ labels, series }));
      get_chart3(({ labels, series }) => setChart3({ labels, series }));
      get_chart4(({ labels, series }) => setChart4({ labels, series }));
      get_chart5(({ labels, series }) => setChart5({ labels, series }));
      get_chart6(({ labels, series }) => setChart6({ labels, series }));
    }, 1000);
  }, []);

  const type = "Line";

  return (
    <>
      <Box
        my={3}
        ml={2}
        p={2}
        borderRadius={16}
        bgcolor="#FFFFFF"
        display="flex"
        flexDirection="column"
        alignItems="space-between"
        justifyContent="space-between"
        className="reporting_main"
      >
        <Typography
          className="reporting_Heading"
          variant="h6"
          display="block"
          gutterBottom
        >
          <span className="reporting">Reporting</span>
        </Typography>
        {/* Line 1 */}
        <Box
          display="flex"
          flexDirection="row"
          alignItems="flex-start"
          justifyContent="space-between"
        >
          <span className="reporting_subheading ">Sales Summary Report</span>

          <span className="reporting_subheading reporting_subheading1">
            {/* Chart 1 */}
            <ChartistGraph
              data={chart1}
              options={line_graph_options}
              type={type}
            />
          </span>
          <Box
            display="flex"
            flexDirection="column"
            alignItems="flex-start"
            justifyContent="flex-start"
            className="reporting_subheading2"
          >
            <ArrowDropUpIcon className="percentage_arrow" />
            <Typography
              className="percentage"
              variant="body1"
              display="block"
              gutterBottom
              color="#51A17C"
            >
              +4.5%
            </Typography>
          </Box>
        </Box>
        {/* Line 2 */}
        <Box
          display="flex"
          flexDirection="row"
          alignItems="flex-start"
          justifyContent="space-between"
        >
          <span className="reporting_subheading ">Sales By Part</span>

          <span className="reporting_subheading reporting_subheading1">
            {/* Chart 2 */}
            <ChartistGraph
              data={chart2}
              options={line_graph_options}
              type={type}
            />
          </span>
          <Box
            display="flex"
            flexDirection="column"
            alignItems="flex-start"
            justifyContent="flex-start"
            className="reporting_subheading2"
          >
            <ArrowDropUpIcon className="percentage_arrow" />
            <Typography
              className="percentage"
              variant="body1"
              display="block"
              gutterBottom
              color="#51A17C"
            >
              +4.5%
            </Typography>
          </Box>
        </Box>
        {/* Lne 3 */}
        <Box
          display="flex"
          flexDirection="row"
          alignItems="flex-start"
          justifyContent="space-between"
        >
          <span className="reporting_subheading ">Employee Comission</span>

          <span className="reporting_subheading reporting_subheading1">
            {/* Chart 3 */}
            <ChartistGraph
              data={chart3}
              options={line_graph_options}
              type={type}
            />
          </span>
          <Box
            display="flex"
            flexDirection="column"
            alignItems="flex-start"
            justifyContent="flex-start"
            className="reporting_subheading2"
          >
            <ArrowDropDownIcon className="percentage_arrow_minus" />
            <Typography
              className="percentage_minus"
              variant="body1"
              display="block"
              gutterBottom
              color="#51A17C"
            >
              -4.5%
            </Typography>
          </Box>
        </Box>
        {/* Lne 4 */}
        <Box
          display="flex"
          flexDirection="row"
          alignItems="flex-start"
          justifyContent="space-between"
        >
          <span className="reporting_subheading ">Low Stock Report</span>

          <span className="reporting_subheading reporting_subheading1">
            {/* Chart 4 */}
            <ChartistGraph
              data={chart4}
              options={line_graph_options}
              type={type}
            />
          </span>
          <Box
            display="flex"
            flexDirection="column"
            alignItems="flex-start"
            justifyContent="flex-start"
            className="reporting_subheading2"
          >
            <ArrowDropUpIcon className="percentage_arrow" />
            <Typography
              className="percentage"
              variant="body1"
              display="block"
              gutterBottom
              color="#51A17C"
            >
              +1.5%
            </Typography>
          </Box>
        </Box>
        {/* Lne 5 */}
        <Box
          display="flex"
          flexDirection="row"
          alignItems="flex-start"
          justifyContent="space-between"
        >
          <span className="reporting_subheading ">Profit and Loss Report</span>

          <span className="reporting_subheading reporting_subheading1">
            {/* Chart 5 */}
            <ChartistGraph
              data={chart5}
              options={line_graph_options}
              type={type}
            />
          </span>
          <Box
            display="flex"
            flexDirection="column"
            alignItems="flex-start"
            justifyContent="flex-start"
            className="reporting_subheading2"
          >
            <ArrowDropDownIcon className="percentage_arrow_minus" />
            <Typography
              className="percentage_minus"
              variant="body1"
              display="block"
              gutterBottom
              color="#51A17C"
            >
              -1.5%
            </Typography>
          </Box>
        </Box>
        {/* Lne 6 */}
        <Box
          display="flex"
          flexDirection="row"
          alignItems="flex-start"
          justifyContent="space-between"
        >
          <span className="reporting_subheading ">Summary Report</span>

          <span className="reporting_subheading reporting_subheading1">
            {/* Chart 6 */}
            <ChartistGraph
              data={chart6}
              options={line_graph_options}
              type={type}
            />
          </span>
          <Box
            display="flex"
            flexDirection="column"
            alignItems="flex-start"
            justifyContent="flex-start"
            className="reporting_subheading2"
          >
            <ArrowDropUpIcon className="percentage_arrow" />
            <Typography
              className="percentage"
              variant="body1"
              display="block"
              gutterBottom
              color="#51A17C"
            >
              +2.5%
            </Typography>
          </Box>
        </Box>
      </Box>
    </>
  );
}
