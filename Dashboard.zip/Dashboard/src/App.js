import React from "react";
import "./App.css";
import Line from "./Components/line";

function App() {
  return (
    <>
      <Line />
    </>
  );
}

export default App;
