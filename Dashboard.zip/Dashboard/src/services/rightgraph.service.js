const genrate_random_array = (length) => {
  for (var a = [], i = 0; i < length; ++i) a[i] = i;

  // http://stackoverflow.com/questions/962802#962890
  function shuffle(array) {
    var tmp,
      current,
      top = array.length;
    if (top)
      while (--top) {
        current = Math.floor(Math.random() * (top + 1));
        tmp = array[current];
        array[current] = array[top];
        array[top] = tmp;
      }
    return array;
  }

  a = shuffle(a);
  return a;
};

export const get_chart1 = (cb) => {
  // api implemenation
  // const resp = await someApiService();
  //   const { dataSet, labels } = resp.data;
  //   ---------------------
  // DUMMY data set
  const labels = [
    "12am|",
    "",
    "",
    "",
    "6am|",
    "",
    "",
    "",
    "12am|",
    "",
    "",
    "",
    "6am|",
  ];
  const series = [[...genrate_random_array(13)]];
  cb({ labels, series });
};

export const get_chart2 = (cb) => {
  // api implemenation
  // const resp = await someApiService();
  //   const { dataSet, labels } = resp.data;
  //   ---------------------
  // DUMMY data set
  const labels = [
    "12am|",
    "",
    "",
    "",
    "6am|",
    "",
    "",
    "",
    "12am|",
    "",
    "",
    "",
    "6am|",
  ];
  const series = [[...genrate_random_array(13)]];
  cb({ labels, series });
};

export const get_chart3 = (cb) => {
  // api implemenation
  // const resp = await someApiService();
  //   const { dataSet, labels } = resp.data;
  //   ---------------------
  // DUMMY data set
  const labels = [
    "12am|",
    "",
    "",
    "",
    "6am|",
    "",
    "",
    "",
    "12am|",
    "",
    "",
    "",
    "6am|",
  ];
  const series = [[...genrate_random_array(13)]];
  cb({ labels, series });
};
